# Настройка Google Таблицы для скринера

Расширение теперь умеет кнопкой "Сохранить" в строке кошелька закидывать его
в твою Google Таблицу. Таблица сама раскладывает всё по двум вкладкам:

- **Кандидаты** — сюда падают все сохранённые из расширения кошельки, со всеми
  цифрами (Win Rate, PNL, баланс и т.д.) и цветовой подсветкой, чтобы было
  легко сравнить и выбрать лучших. Есть колонка **Оценка** — простая формула
  прямо в таблице (не зашита в код), которую можно менять под себя.
- **В работе** — сюда переезжает кошелёк, как только ты ставишь галочку в
  колонке "В работу" у него в "Кандидаты" (и пропадает из "Кандидаты"). Здесь
  вручную ведёшь статус (Активно/Пауза/Остановлено), результат сделок и
  заметки — чтобы по ходу копитрейдинга видеть, кого продолжать, а кого нет.

Так как вас минимум двое (ты и Олег), у **каждого своя копия таблицы** и своя
ссылка в настройках расширения — данные не мешаются. Ниже — как сделать
таблицу один раз себе, и как переслать шаблон Олегу.

## Шаг 1. Создай Google Таблицу

Зайди на [sheets.google.com](https://sheets.google.com) → "Новая таблица".
Дай ей любое название, например "Robinhood Screener — Даня".

## Шаг 2. Вставь скрипт

1. В таблице: **Расширения → Apps Script**.
2. Откроется редактор с файлом `Code.gs` — там будет заготовка `function myFunction() {}`.
   Выдели всё (Ctrl+A) и удали.
3. Скопируй код целиком из блока ниже и вставь в редактор.
4. Сверху нажми значок дискеты (Сохранить проект).

```javascript
/**
 * Robinhood Chain Wallet Screener — бэкенд на Google Таблице (Apps Script).
 *
 * Что делает:
 *  - принимает кошельки из расширения (кнопка "Сохранить" в таблице результатов)
 *    и добавляет их строкой во вкладку "Кандидаты";
 *  - когда в "Кандидаты" ставишь галочку в колонке "В работу" — строка сама
 *    переезжает во вкладку "В работе" (для ручного трекинга по факту копитрейдинга)
 *    и исчезает из "Кандидаты".
 *
 * Как поставить (см. подробности в SHEETS_SETUP.md):
 *  1. Создай новую Google Таблицу.
 *  2. Расширения → Apps Script → вставь сюда весь этот файл целиком (замени
 *     содержимое Code.gs).
 *  3. Сверху в редакторе выбери функцию initializeSheets и нажми ▶ Выполнить
 *     (один раз — попросит авторизацию, это нормально, это твой собственный скрипт).
 *  4. Разверни → Новое развёртывание → Веб-приложение → Execute as: Me,
 *     Who has access: Anyone → Развернуть → скопируй URL.
 *  5. Вставь этот URL в попап расширения (поле "Ссылка на Google Таблицу").
 */

const CANDIDATES_SHEET = 'Кандидаты';
const ACTIVE_SHEET = 'В работе';

const CANDIDATE_HEADERS = [
  'Добавлено', 'Кошелёк', 'GMGN', 'Robinscan', 'Токен(ы)', 'Найдено в N токенах',
  'ETH баланс', 'Баланс токена', 'Win Rate %', 'Realized PNL %', 'Realized Profit $',
  'Buy', 'Sell', 'Сделок (расчёт)', 'Токенов всего', 'Период (дней)', 'Оценка', 'В работу'
];
// Индексы столбцов (1-based), используются в формулах/форматировании ниже.
const COL = {
  ADDED: 1, WALLET: 2, GMGN: 3, ROBINSCAN: 4, TOKENS: 5, FOUND_IN: 6,
  ETH: 7, TOKEN_BAL: 8, WIN_RATE: 9, PNL: 10, PROFIT: 11,
  BUY: 12, SELL: 13, SAMPLE: 14, TOKEN_NUM: 15, PERIOD: 16, SCORE: 17, CHECKBOX: 18
};

const ACTIVE_HEADERS = [
  'Дата начала', 'Кошелёк', 'GMGN', 'Robinscan', 'Токен(ы)',
  'ETH баланс (на отбор)', 'Win Rate % (на отбор)', 'Realized PNL % (на отбор)', 'Оценка (на отбор)',
  'Статус', 'Кол-во скопированных сделок', 'Результат $', 'Результат %', 'Заметки'
];
const ACOL = { START: 1, WALLET: 2, GMGN: 3, ROBINSCAN: 4, TOKENS: 5, ETH: 6, WIN_RATE: 7, PNL: 8, SCORE: 9, STATUS: 10 };

const MAX_ROWS = 1000; // на сколько строк вперёд ставим форматирование/чекбоксы/валидацию

// ---------- разовая настройка обеих вкладок ----------
function initializeSheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  setupCandidatesSheet(ss);
  setupActiveSheet(ss);

  // дефолтный "Лист1"/"Sheet1" больше не нужен, если он пустой
  const def = ss.getSheetByName('Sheet1') || ss.getSheetByName('Лист1');
  if (def && ss.getSheets().length > 2 && def.getLastRow() === 0) {
    ss.deleteSheet(def);
  }
  SpreadsheetApp.getUi().alert('Готово! Вкладки "Кандидаты" и "В работе" настроены.\n\nТеперь: Развернуть → Новое развёртывание → Веб-приложение (Execute as: Me, Who has access: Anyone) и скопируй URL в попап расширения.');
}

function setupCandidatesSheet(ss) {
  let sheet = ss.getSheetByName(CANDIDATES_SHEET);
  if (!sheet) sheet = ss.insertSheet(CANDIDATES_SHEET);
  sheet.clear();
  sheet.clearConditionalFormatRules();

  sheet.getRange(1, 1, 1, CANDIDATE_HEADERS.length).setValues([CANDIDATE_HEADERS]);
  sheet.getRange(1, 1, 1, CANDIDATE_HEADERS.length).setFontWeight('bold').setBackground('#1a1a1a').setFontColor('#ffffff');
  sheet.setFrozenRows(1);
  sheet.setFrozenColumns(2);
  sheet.autoResizeColumns(1, CANDIDATE_HEADERS.length);

  // ВАЖНО: чекбоксы НЕ проставляем заранее на MAX_ROWS строк вперёд — Google Таблица
  // считает клетку с чекбоксом "занятой", из-за этого appendRow() в doPost() добавлял
  // новую запись не во 2-ю строку, а после всех заранее проставленных (то есть куда-то
  // в район 1000-й строки, далеко за пределами видимой области — выглядело так, будто
  // сохранение не работает). Чекбокс на каждую строку ставится отдельно, только когда
  // для неё реально приходят данные — см. doPost() и moveToActive() ниже.

  applyCandidateFormatting(sheet);

  recreateFilter(sheet, CANDIDATE_HEADERS.length);
}

// На листе может быть только ОДИН фильтр — если запустить initializeSheets повторно,
// createFilter() без этой проверки падает с ошибкой "На листе можно создать только
// один фильтр" (и обрывает всю настройку на середине). Поэтому сперва убираем старый.
function recreateFilter(sheet, numColumns) {
  const existing = sheet.getFilter();
  if (existing) existing.remove();
  sheet.getRange(1, 1, MAX_ROWS, numColumns).createFilter();
}

function applyCandidateFormatting(sheet) {
  const rules = [];
  const range = (col) => sheet.getRange(2, col, MAX_ROWS, 1);

  // цветовая шкала: Win Rate, PNL, Оценка — главные "на глаз" сигналы для сравнения
  [COL.WIN_RATE, COL.PNL, COL.SCORE].forEach((col) => {
    rules.push(
      SpreadsheetApp.newConditionalFormatRule()
        .setGradientMaxpointWithValue('#57bb8a', SpreadsheetApp.InterpolationType.NUMBER, '100')
        .setGradientMidpointWithValue('#3c3c1e', SpreadsheetApp.InterpolationType.PERCENT, '50')
        .setGradientMinpointWithValue('#b33939', SpreadsheetApp.InterpolationType.NUMBER, '-20')
        .setRanges([range(col)])
        .build()
    );
  });

  // жёлтая подсветка, если кошелёк всплыл сразу в нескольких токенах — сильный сигнал
  rules.push(
    SpreadsheetApp.newConditionalFormatRule()
      .whenNumberGreaterThanOrEqualTo(2)
      .setBackground('#3a2f00')
      .setFontColor('#ffd54a')
      .setBold(true)
      .setRanges([range(COL.FOUND_IN)])
      .build()
  );

  // серым и курсивом — если выборка для Win Rate/PNL меньше 3 токенов (метрике доверять меньше)
  rules.push(
    SpreadsheetApp.newConditionalFormatRule()
      .whenNumberLessThan(3)
      .setFontColor('#888888')
      .setItalic(true)
      .setRanges([range(COL.SAMPLE)])
      .build()
  );

  sheet.setConditionalFormatRules(rules);
}

function setupActiveSheet(ss) {
  let sheet = ss.getSheetByName(ACTIVE_SHEET);
  if (!sheet) sheet = ss.insertSheet(ACTIVE_SHEET);
  sheet.clear();
  sheet.clearConditionalFormatRules();

  sheet.getRange(1, 1, 1, ACTIVE_HEADERS.length).setValues([ACTIVE_HEADERS]);
  sheet.getRange(1, 1, 1, ACTIVE_HEADERS.length).setFontWeight('bold').setBackground('#1a1a1a').setFontColor('#ffffff');
  sheet.setFrozenRows(1);
  sheet.setFrozenColumns(2);
  sheet.autoResizeColumns(1, ACTIVE_HEADERS.length);

  // выпадающий список "Статус"
  const statusRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['Активно', 'Пауза', 'Остановлено'], true)
    .setAllowInvalid(false)
    .build();
  sheet.getRange(2, ACOL.STATUS, MAX_ROWS, 1).setDataValidation(statusRule);

  // цветовая подсветка статуса
  const statusRules = [
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('Активно').setBackground('#1e5c2e').setFontColor('#ffffff')
      .setRanges([sheet.getRange(2, ACOL.STATUS, MAX_ROWS, 1)]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('Остановлено').setBackground('#5c1e1e').setFontColor('#ffffff')
      .setRanges([sheet.getRange(2, ACOL.STATUS, MAX_ROWS, 1)]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('Пауза').setBackground('#5c4a1e').setFontColor('#ffffff')
      .setRanges([sheet.getRange(2, ACOL.STATUS, MAX_ROWS, 1)]).build()
  ];
  sheet.setConditionalFormatRules(statusRules);

  recreateFilter(sheet, ACTIVE_HEADERS.length);
}

// ---------- приём кошелька из расширения ----------
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    if (!data.wallet) throw new Error('В запросе нет адреса кошелька');

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(CANDIDATES_SHEET);
    if (!sheet) { setupCandidatesSheet(ss); sheet = ss.getSheetByName(CANDIDATES_SHEET); }

    const row = new Array(CANDIDATE_HEADERS.length).fill('');
    row[COL.ADDED - 1] = new Date();
    row[COL.WALLET - 1] = data.wallet;
    row[COL.GMGN - 1] = data.gmgnLink || `https://gmgn.ai/robinhood/address/${data.wallet}`;
    row[COL.ROBINSCAN - 1] = data.robinscanLink || `https://robinscan.io/address/${data.wallet}`;
    row[COL.TOKENS - 1] = data.tokens || '';
    row[COL.FOUND_IN - 1] = data.foundInTokens || 1;
    row[COL.ETH - 1] = data.ethBalance ?? '';
    row[COL.TOKEN_BAL - 1] = data.tokenBalance ?? '';
    row[COL.WIN_RATE - 1] = data.winRate ?? '';
    row[COL.PNL - 1] = data.realizedPnl ?? '';
    row[COL.PROFIT - 1] = data.realizedProfit ?? '';
    row[COL.BUY - 1] = data.buyCount ?? '';
    row[COL.SELL - 1] = data.sellCount ?? '';
    row[COL.SAMPLE - 1] = data.tradedTokenNum ?? '';
    row[COL.TOKEN_NUM - 1] = data.tokenNum ?? '';
    row[COL.PERIOD - 1] = data.periodDays ?? '';
    row[COL.CHECKBOX - 1] = false;

    sheet.appendRow(row);
    const r = sheet.getLastRow();

    // Оценка — обычная формула в самой таблице (не зашита в скрипт), её можно
    // смело менять под себя: 0.5×WinRate + 0.3×PNL(зажат в [-100;200]) +
    // 15×(найдено в N токенах − 1) + бонус/штраф за размер выборки.
    sheet.getRange(r, COL.SCORE).setFormula(
      `=IFERROR(ROUND(I${r}*0.5 + MAX(MIN(J${r},200),-100)*0.3 + (F${r}-1)*15 + IF(N${r}>=3,10,IF(N${r}<2,-20,0)),1),0)`
    );
    sheet.getRange(r, COL.CHECKBOX).insertCheckboxes();

    return ContentService.createTextOutput(JSON.stringify({ ok: true, row: r })).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ ok: false, error: String(err) })).setMimeType(ContentService.MimeType.JSON);
  }
}

// ---------- галочка "В работу" -> переносим строку во вкладку "В работе" ----------
function onEdit(e) {
  try {
    const sheet = e.range.getSheet();
    if (sheet.getName() !== CANDIDATES_SHEET) return;
    if (e.range.getRow() === 1) return;
    if (e.range.getColumn() !== COL.CHECKBOX) return;
    if (e.value !== 'TRUE') return;

    const row = e.range.getRow();
    const rowValues = sheet.getRange(row, 1, 1, CANDIDATE_HEADERS.length).getValues()[0];
    moveToActive(rowValues);
    sheet.deleteRow(row);
  } catch (err) {
    console.error(err);
  }
}

function moveToActive(rowValues) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let active = ss.getSheetByName(ACTIVE_SHEET);
  if (!active) { setupActiveSheet(ss); active = ss.getSheetByName(ACTIVE_SHEET); }

  const newRow = new Array(ACTIVE_HEADERS.length).fill('');
  newRow[ACOL.START - 1] = new Date();
  newRow[ACOL.WALLET - 1] = rowValues[COL.WALLET - 1];
  newRow[ACOL.GMGN - 1] = rowValues[COL.GMGN - 1];
  newRow[ACOL.ROBINSCAN - 1] = rowValues[COL.ROBINSCAN - 1];
  newRow[ACOL.TOKENS - 1] = rowValues[COL.TOKENS - 1];
  newRow[ACOL.ETH - 1] = rowValues[COL.ETH - 1];
  newRow[ACOL.WIN_RATE - 1] = rowValues[COL.WIN_RATE - 1];
  newRow[ACOL.PNL - 1] = rowValues[COL.PNL - 1];
  newRow[ACOL.SCORE - 1] = rowValues[COL.SCORE - 1];
  newRow[ACOL.STATUS - 1] = 'Активно';

  active.appendRow(newRow);
  const r = active.getLastRow();
  const statusRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['Активно', 'Пауза', 'Остановлено'], true)
    .setAllowInvalid(false)
    .build();
  active.getRange(r, ACOL.STATUS).setDataValidation(statusRule);
}
```

## Шаг 3. Запусти настройку один раз

1. В верхней панели редактора Apps Script (рядом с ▶) есть выпадающий список
   функций — выбери **initializeSheets**.
2. Нажми ▶ **Выполнить**.
3. Появится запрос авторизации — это Google спрашивает разрешение на то, что
   *твой собственный* скрипт будет работать с *твоей же* таблицей. Нажми
   "Проверить разрешения" → выбери свой аккаунт → внизу будет предупреждение
   "Google не проверил это приложение" (это нормально для собственных
   скриптов) → "Дополнительные настройки" → "Перейти на (название проекта),
   небезопасно" → "Разрешить".
4. Вернись в таблицу — появятся две вкладки: **Кандидаты** и **В работе**, уже
   с заголовками и подсветкой.

## Шаг 4. Разверни как веб-приложение

1. В Apps Script: **Развернуть → Новое развёртывание**.
2. Тип — **Веб-приложение**.
3. **Execute as**: Me (твой аккаунт).
4. **Who has access**: **Anyone** (это НЕ значит, что таблица публичная —
   публичным становится только сам приёмный адрес для записи данных;
   саму таблицу видишь только ты, пока не расшаришь её отдельно).
5. Нажми **Развернуть**, ещё раз подтверди авторизацию, если попросит.
6. Скопируй появившийся **URL веб-приложения** (вид
   `https://script.google.com/macros/s/AKfycb.../exec`).

## Шаг 5. Вставь ссылку в расширение

Открой попап расширения → поле "Ссылка на Google Таблицу (Web App URL)" →
вставь скопированный URL → "Сохранить и запустить". Теперь кнопка
"Сохранить" в строке кошелька будет закидывать его в твою таблицу.

## Как переслать это Олегу

Раз у каждого свои данные — Олегу нужна **своя** копия таблицы (и свой
Web App URL), а не доступ к твоей:

1. В своей готовой таблице: **Файл → Сделать копию** → отправь ему ссылку на
   копию (или просто перешли файл).
2. Олег открывает копию у себя — скрипт (Code.gs) уже внутри, копируется
   вместе с таблицей, ничего вставлять заново не надо.
3. Но развёртывание (Web App URL) не копируется — Олегу нужно самому
   повторить **Шаг 4** (Развернуть → Новое развёртывание → Веб-приложение →
   Execute as: Me, Anyone) в СВОЕЙ копии и получить СВОЙ URL.
4. Этот URL Олег вставляет в настройки СВОЕГО расширения (расширение ему
   отправляешь просто как папку/zip, как обычно).

Так каждый пишет в свою таблицу, но структура (вкладки, форматирование,
формула Оценки) у всех одинаковая, потому что расходится из одного шаблона.

## Если что-то не сохраняется

Расширение теперь честно показывает "Ошибка", если Google Таблица не
подтвердила запись явным `{ ok: true }` — "✓ Сохранено" больше не показывается
"на всякий случай". Если видишь ошибку (или строка не появилась, хотя ошибки
не было — это версия расширения до этого фикса), проверяй по порядку:

1. **View → Executions** в редакторе Apps Script — самый быстрый способ понять,
   дошёл ли вообще вызов от расширения. Если там пусто после нажатия
   "Сохранить" — запрос не дошёл (см. пункт 3 ниже, скорее всего не тот URL
   или не то развёртывание). Если есть запись с ошибкой — открой её, там будет
   текст ошибки.
2. Проверь, что при развёртывании стоит именно **Anyone** (не "Anyone with
   Google account" — расширению неоткуда взять твой Google-логин). Смотри в
   **Развернуть → Управление развёртываниями**.
3. Если правил код и переразвернул — при "Новое развёртывание" получается
   НОВЫЙ URL, старый перестаёт работать. Не забудь обновить ссылку в попапе.
   Чтобы обновлять код без смены URL — используй "Управление развёртываниями"
   → значок карандаша → тип "Новая версия" (не "Новое развёртывание").
4. Открывай именно ту таблицу, из которой разворачивал скрипт — если успел
   сделать копию (например, готовя шаблон для Олега) и сейчас смотришь не в
   ту вкладку браузера, данные закономерно будут в другом файле.
5. **Не запускай `initializeSheets` повторно после того, как в таблице уже
   есть сохранённые кошельки** — функция полностью очищает обе вкладки
   (`sheet.clear()`) и создаёт их заново с нуля. Она для разовой настройки, не
   для "обновить" или "проверить, что всё ок".
