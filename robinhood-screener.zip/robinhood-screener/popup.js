document.addEventListener('DOMContentLoaded', async () => {
  const minEthBalanceInput = document.getElementById('minEthBalance');
  const minWinRateInput = document.getElementById('minWinRate');
  const minRealizedPnlInput = document.getElementById('minRealizedPnl');
  const minTokenNumInput = document.getElementById('minTokenNum');
  const minTradesInput = document.getElementById('minTrades');
  const hideNoiseInput = document.getElementById('hideNoise');
  const extraTokensTextarea = document.getElementById('extraTokens');
  const sheetsUrlInput = document.getElementById('sheetsUrl');
  const walletsTextarea = document.getElementById('wallets');

  // Загружаем настройки
  const {
    minEthBalance = 0.05,
    minWinRate = 50,
    minRealizedPnl = 0,
    minTokenNum = 0,
    minTrades = 0,
    hideNoise = true,
    extraTokens = '',
    sheetsUrl = ''
  } = await chrome.storage.local.get([
    'minEthBalance', 'minWinRate', 'minRealizedPnl', 'minTokenNum', 'minTrades',
    'hideNoise', 'extraTokens', 'sheetsUrl'
  ]);

  minEthBalanceInput.value = minEthBalance;
  minWinRateInput.value = minWinRate;
  minRealizedPnlInput.value = minRealizedPnl;
  minTokenNumInput.value = minTokenNum;
  minTradesInput.value = minTrades;
  hideNoiseInput.checked = hideNoise !== false;
  extraTokensTextarea.value = extraTokens;
  sheetsUrlInput.value = sheetsUrl;

  document.getElementById('save').addEventListener('click', async () => {
    const sheetsUrlValue = sheetsUrlInput.value.trim();

    if (sheetsUrlValue && !/^https:\/\/script\.google(usercontent)?\.com\//.test(sheetsUrlValue)) {
      alert('Ссылка на Google Таблицу выглядит не как Web App URL (должна начинаться с https://script.google.com/macros/s/.../exec). Проверь SHEETS_SETUP.md — если не уверен, просто очисти это поле, кнопка "Сохранить" в таблице тогда будет неактивна.');
      return;
    }

    // Сохраняем настройки
    await chrome.storage.local.set({
      minEthBalance: parseFloat(minEthBalanceInput.value) || 0,
      minWinRate: parseFloat(minWinRateInput.value) || 0,
      minRealizedPnl: parseFloat(minRealizedPnlInput.value) || 0,
      minTokenNum: parseInt(minTokenNumInput.value) || 0,
      minTrades: parseInt(minTradesInput.value) || 0,
      hideNoise: hideNoiseInput.checked,
      extraTokens: extraTokensTextarea.value,
      sheetsUrl: sheetsUrlValue
    });

    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});

    if (!tab?.url || !/^https:\/\/gmgn\.ai\/robinhood\/token\//.test(tab.url)) {
      alert('Открой страницу токена на gmgn.ai (вида https://gmgn.ai/robinhood/token/0x...), а потом снова открой этот попап.');
      return;
    }

    const extraTokensList = extraTokensTextarea.value
      .split('\n')
      .map(t => t.trim())
      .filter(t => /^0x[a-fA-F0-9]{40}$/.test(t));

    try {
      await chrome.tabs.sendMessage(tab.id, {
        action: 'runInit',
        wallets: walletsTextarea.value.split('\n'),
        extraTokens: extraTokensList
      });
    } catch (e) {
      alert('Не получилось достучаться до страницы. Перезагрузи вкладку с токеном (F5) и попробуй снова — content-скрипт мог не успеть подключиться.');
      return;
    }

    window.close();
  });
});
