// content.js — Robinhood Chain wallet screener v2.1 — данные напрямую с GMGN.AI
//
// v2 (первая версия без Bitquery) считала Win Rate как "на скольких из
// ПРОВЕРЕННЫХ токенов кошелёк вышел в плюс". Если проверяли только текущий
// токен (без доп. токенов в попапе) — это давало вырожденный результат:
// 100% у всех, кто в плюсе по этому токену, 0% у остальных (Даня поймал это
// на скриншоте — почти все строки 100.0%, хотя у самого GMGN на странице
// кошелька Winrate 14-40%). Метрика была математически "верна" при своём
// определении, но не тем, что ожидаешь увидеть, и бесполезна на одном токене.
//
// ИСПРАВЛЕНО в v2.1: нашёлся эндпоинт самого GMGN, который отдаёт РЕАЛЬНЫЙ
// Win Rate кошелька — тот же, что показывает сама gmgn.ai во всплывающей
// подсказке/на странице кошелька — и работает БЕЗ логина:
//
//   GET /pf/api/v1/wallet/robinhood/{wallet}/wallet_token_info?token_address={token}
//
// В ответе два слоя:
//  - верхний уровень (total_profit, total_profit_pnl, maker_token_tags) — это
//    ВСЕ ВРЕМЯ и ПО ОДНОМУ конкретному токену (тому, что передали в token_address);
//  - data.wallet_stat (win_rate_7d, realized_pnl_7d, realized_profit_7d, buy_7d,
//    sell_7d, token_num) — это НАСТОЯЩИЙ агрегат кошелька за 7 дней ПО ВСЕМ
//    токенам сразу — те же цифры, что в интерфейсе GMGN. Проверено вживую:
//    win_rate_7d не зависит от того, какой token_address передан (можно смело
//    слать текущий токен страницы для всех кошельков одним и тем же запросом).
//
// Поэтому теперь: холдеры/трейдеры токена (до 100+100 на токен, см. ниже) —
// это только СПИСОК КАНДИДАТОВ (плюс их ETH-баланс, он идёт бесплатно в том
// же ответе). А Win Rate/PNL/Buy/Sell в таблице — это уже отдельный вызов
// wallet_token_info на каждого кандидата, с настоящими числами GMGN.
//
// Второй баг Олега ("1.5К холдеров, проверяет 38, даёт 4") решается тем, что
// /vas/api/v1/token_holders и /vas/api/v1/token_traders отдают до 100 записей
// каждый (проверено вживую на токене с 10.7К холдеров) — втрое больше старого
// потолка Bitquery в 30, и без ключа/лимитов.

const HISTORY_KEY = 'walletHistory';
const HISTORY_CAP = 2000; // защита chrome.storage.local от разрастания
const PAGE_SIZE = 100; // максимум, который отдаёт GMGN за один запрос (20/50/100 — валидные значения, всё остальное тихо откатывается на 20)
const NOISE_TAGS = ['creator', 'dev_team']; // сам разработчик токена — не "смарт-мани", это создатель монеты
const ENRICH_CONCURRENCY = 10; // сколько параллельных запросов wallet_token_info держим одновременно

// ---------- ПРО ОТСУТСТВИЕ ПАГИНАЦИИ ----------
// У token_holders/token_traders в ответе есть поле "next" (похоже на курсор для
// пагинации), но проверено вживую: ни один из ~16 разумных вариантов названия
// параметра (cursor/next/page_token/offset/from/...) не работает — сервер
// всегда тихо отдаёт первую страницу заново. Похоже, курсор зарезервирован
// для другого клиента (мобильное приложение / платный API), а не для этого
// публичного веб-эндпоинта. Поэтому вместо пагинации берём НЕСКОЛЬКО разных
// сортировок (каждая до 100 записей) и объединяем — так на одном токене
// реально получается 400-450+ уникальных кошельков вместо 100 (проверено).
// Не все значения orderby валидны — эти проверены вживую (остальные отдают
// code=40000301 P_GMGN_WEB_INVALID_ARGUMENT):
const HOLDER_SORTS = ['amount_percentage', 'last_active_timestamp', 'profit', 'realized_profit'];
const TRADER_SORTS = ['profit', 'realized_profit', 'amount_percentage', 'last_active_timestamp', 'buy_volume_cur', 'sell_volume_cur', 'netflow_usd'];

function gmgnLink(wallet) {
  return `https://gmgn.ai/robinhood/address/${wallet}`;
}
function robinscanAddressLink(wallet) {
  return `https://robinscan.io/address/${wallet}`;
}

function getTokenAddressFromUrl() {
  const match = window.location.pathname.match(/\/robinhood\/token\/(0x[a-fA-F0-9]{40})/i);
  return match ? match[1].toLowerCase() : null;
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === 'runInit') {
    chrome.storage.local.get([
      'minEthBalance', 'minWinRate', 'minRealizedPnl', 'minTokenNum', 'minTrades',
      'hideNoise', 'sheetsUrl'
    ]).then((settings) => {
      init({ wallets: message.wallets, extraTokens: message.extraTokens || [], ...settings });
    });
  }
});

// ---------- wei (строка) -> ETH (число), без потери точности через BigInt ----------
function weiToEth(weiStr) {
  try {
    const raw = BigInt(weiStr || '0');
    const whole = raw / 1000000000000000000n;
    const remainder = raw % 1000000000000000000n;
    const decStr = remainder.toString().padStart(18, '0').slice(0, 6);
    return parseFloat(`${whole}.${decStr}`);
  } catch (e) {
    return NaN;
  }
}

// ---------- запрос к собственному API GMGN (тот же origin — без CORS, без ключа) ----------
async function gmgnGet(path, params) {
  const qs = new URLSearchParams(params).toString();
  const response = await fetch(`https://gmgn.ai${path}${qs ? '?' + qs : ''}`, { credentials: 'include' });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const json = await response.json();
  if (json.code !== 0) throw new Error(json.reason || `GMGN вернул code=${json.code}`);
  return json.data;
}

async function fetchHoldersBySort(tokenAddress, orderby) {
  try {
    const data = await gmgnGet(`/vas/api/v1/token_holders/robinhood/${tokenAddress}`, {
      limit: PAGE_SIZE, cost: 20, orderby, direction: 'desc'
    });
    return data.list || [];
  } catch (e) {
    console.error(`Ошибка получения holders (orderby=${orderby}) для`, tokenAddress, e);
    return [];
  }
}

async function fetchTradersBySort(tokenAddress, orderby) {
  try {
    const data = await gmgnGet(`/vas/api/v1/token_traders/robinhood/${tokenAddress}`, {
      limit: PAGE_SIZE, orderby, direction: 'desc'
    });
    return data.list || [];
  } catch (e) {
    console.error(`Ошибка получения traders (orderby=${orderby}) для`, tokenAddress, e);
    return [];
  }
}

// ---------- собираем максимум кандидатов по токену: несколько сортировок holders + traders, объединяем ----------
async function fetchAllCandidates(tokenAddress) {
  const [holderLists, traderLists] = await Promise.all([
    Promise.all(HOLDER_SORTS.map(s => fetchHoldersBySort(tokenAddress, s))),
    Promise.all(TRADER_SORTS.map(s => fetchTradersBySort(tokenAddress, s)))
  ]);
  return [...holderLists.flat(), ...traderLists.flat()];
}

// ---------- настоящий Win Rate/PNL кошелька (7Д, по всем токенам) + профит по конкретному токену ----------
async function fetchWalletTokenInfo(wallet, tokenAddress) {
  try {
    const data = await gmgnGet(`/pf/api/v1/wallet/robinhood/${wallet}/wallet_token_info`, { token_address: tokenAddress });
    const ws = data.wallet_stat || {};
    return {
      winRate7d: parseFloat(ws.win_rate_7d ?? 0) * 100,
      realizedPnl7d: parseFloat(ws.realized_pnl_7d ?? 0) * 100,
      realizedProfit7d: parseFloat(ws.realized_profit_7d ?? 0),
      buy7d: ws.buy_7d ?? 0,
      sell7d: ws.sell_7d ?? 0,
      tokenNum7d: ws.token_num ?? 0,
      thisTokenProfit: parseFloat(data.total_profit ?? 0),
      thisTokenPnl: parseFloat(data.total_profit_pnl ?? 0) * 100,
      tags: [...(data.maker_token_tags || []), ...((data.maker_info && data.maker_info.tags) || [])]
    };
  } catch (e) {
    console.error('Ошибка получения wallet_token_info для', wallet, e);
    return null;
  }
}

// ---------- запуск N задач с ограничением на параллельность ----------
async function runWithConcurrency(items, limit, worker) {
  const results = new Array(items.length);
  let next = 0;
  async function runOne() {
    while (true) {
      const i = next++;
      if (i >= items.length) return;
      results[i] = await worker(items[i], i);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, runOne));
  return results;
}

// ---------- история кошельков между запусками (chrome.storage.local) ----------
async function loadHistory() {
  const { [HISTORY_KEY]: history = {} } = await chrome.storage.local.get([HISTORY_KEY]);
  return history;
}

function bumpHistory(history, wallet, passed) {
  const prior = history[wallet]?.timesPassed || 0;
  const entry = history[wallet] || { firstSeen: Date.now(), timesChecked: 0, timesPassed: 0 };
  entry.timesChecked++;
  if (passed) entry.timesPassed++;
  entry.lastSeen = Date.now();
  history[wallet] = entry;
  return prior;
}

async function saveHistory(history) {
  const keys = Object.keys(history);
  if (keys.length > HISTORY_CAP) {
    const sorted = keys.sort((a, b) => (history[a].lastSeen || 0) - (history[b].lastSeen || 0));
    for (const k of sorted.slice(0, keys.length - HISTORY_CAP)) delete history[k];
  }
  await chrome.storage.local.set({ [HISTORY_KEY]: history });
}

// ---------- сохранение кошелька в Google Таблицу (Apps Script Web App) ----------
async function saveToSheet(sheetsUrl, payload) {
  const response = await fetch(sheetsUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify(payload)
  });
  let json = null;
  try { json = await response.json(); } catch (e) { /* см. ниже */ }
  if (!json || json.ok !== true) {
    const reason = json?.error
      ? json.error
      : `сервер ответил не тем, что ожидалось (HTTP ${response.status}). Проверь: доступ веб-приложения — "Anyone" (не "Anyone with Google account"); развёрнута последняя версия скрипта (Управление развёртываниями → карандаш → Новая версия); в Apps Script — View → Executions, там видно, дошёл ли вызов и что пошло не так.`;
    throw new Error(reason);
  }
  return true;
}

// ---------- рендер одной строки таблицы ----------
function renderRowElement(rowData, sheetsUrl) {
  const tr = document.createElement('tr');
  const td = (html, align = 'right') => {
    const cell = document.createElement('td');
    cell.style.cssText = `border:1px solid #333; padding:8px; text-align:${align};`;
    cell.innerHTML = html;
    return cell;
  };

  const walletCell = document.createElement('td');
  walletCell.style.cssText = 'border:1px solid #333; padding:8px;';
  walletCell.title = rowData.wallet;
  walletCell.innerHTML = `
    <a href="${robinscanAddressLink(rowData.wallet)}" target="_blank" style="color:#fff; text-decoration:none;">${rowData.wallet.slice(0, 6)}…${rowData.wallet.slice(-4)}</a>
    <button class="copy-btn" style="margin-left:4px; width:auto; padding:1px 5px; font-size:11px;" title="Скопировать адрес">⧉</button>`;
  walletCell.querySelector('.copy-btn').addEventListener('click', () => {
    navigator.clipboard?.writeText(rowData.wallet).then(() => {
      const btn = walletCell.querySelector('.copy-btn');
      btn.textContent = '✓';
      setTimeout(() => { btn.textContent = '⧉'; }, 1200);
    }).catch(() => {});
  });
  tr.appendChild(walletCell);

  const noTrades7d = (rowData.buyCount + rowData.sellCount) === 0;
  const dashOr = (html) => noTrades7d ? '<span style="color:#666;" title="0 сделок за 7Д — цифра не показательна">—</span>' : html;

  tr.appendChild(td(isNaN(rowData.ethBalance) ? '?' : rowData.ethBalance.toFixed(3)));
  tr.appendChild(td(dashOr(`${rowData.winRate.toFixed(1)}%`), 'right'));
  tr.appendChild(td(dashOr(rowData.realizedPnl.toFixed(1) + '%')));
  tr.appendChild(td(dashOr('$' + rowData.realizedProfit.toFixed(2))));
  tr.appendChild(td(String(rowData.buyCount)));
  tr.appendChild(td(String(rowData.sellCount)));
  tr.appendChild(td(String(rowData.tokenNum7d), 'right'));

  const thisTokenStyle = rowData.thisTokenProfit > 0 ? 'color:#7fd97f;' : rowData.thisTokenProfit < 0 ? 'color:#e07777;' : '';
  tr.appendChild(td(`<span style="${thisTokenStyle}" title="Профит по ЭТОМУ токену за всё время">$${rowData.thisTokenProfit.toFixed(2)}</span>`));

  const foundStyle = rowData.foundInTokens >= 2 ? 'background:#3a2f00; color:#ffd54a; font-weight:bold; border-radius:3px; padding:1px 4px;' : '';
  tr.appendChild(td(`<span style="${foundStyle}">${rowData.foundInTokens}</span>`));

  const tagsStr = rowData.tags.length ? rowData.tags.join(', ') : '—';
  tr.appendChild(td(`<span style="font-size:11px; color:#aaa;" title="Метки от GMGN">${tagsStr}</span>`, 'left'));

  tr.appendChild(td(rowData.priorPassed > 0 ? `<span style="color:#7fd97f; font-weight:bold;">${rowData.priorPassed}</span>` : '0'));

  tr.appendChild(td(`<a href="${gmgnLink(rowData.wallet)}" target="_blank" style="color:#8ab4ff;">GMGN ↗</a>`, 'center'));

  const saveCell = document.createElement('td');
  saveCell.style.cssText = 'border:1px solid #333; padding:8px; text-align:center;';
  const saveBtn = document.createElement('button');
  saveBtn.textContent = 'Сохранить';
  saveBtn.style.cssText = 'width:auto; padding:3px 8px; font-size:11px;';
  if (!sheetsUrl) {
    saveBtn.disabled = true;
    saveBtn.title = 'Укажи ссылку на Google Таблицу в настройках расширения';
  } else {
    saveBtn.addEventListener('click', async () => {
      saveBtn.disabled = true;
      saveBtn.textContent = 'Отправляю…';
      try {
        await saveToSheet(sheetsUrl, {
          wallet: rowData.wallet,
          gmgnLink: gmgnLink(rowData.wallet),
          robinscanLink: robinscanAddressLink(rowData.wallet),
          tokens: rowData.tokens.join(', '),
          foundInTokens: rowData.foundInTokens,
          ethBalance: rowData.ethBalance,
          tokenBalance: rowData.thisTokenProfit, // в v2.1: "баланс токена" -> используем как поле для профита по этому токену
          winRate: rowData.winRate,
          realizedPnl: rowData.realizedPnl,
          realizedProfit: rowData.realizedProfit,
          buyCount: rowData.buyCount,
          sellCount: rowData.sellCount,
          tradedTokenNum: rowData.tokenNum7d,
          tokenNum: rowData.tokenNum7d,
          periodDays: '7' // теперь всегда 7Д — так считает сам GMGN (wallet_stat.*_7d)
        });
        saveBtn.textContent = '✓ Сохранено';
        saveBtn.style.background = '#1e5c2e';
        saveBtn.style.color = '#fff';
      } catch (e) {
        console.error('Ошибка сохранения в Google Таблицу:', e);
        saveBtn.textContent = 'Ошибка ⟳';
        saveBtn.disabled = false;
        alert('Не удалось сохранить в таблицу: ' + e.message + '\n\nПроверь ссылку в настройках и SHEETS_SETUP.md (доступ веб-приложения должен быть "Anyone").');
      }
    });
  }
  saveCell.appendChild(saveBtn);
  tr.appendChild(saveCell);

  return tr;
}

const COLUMNS = [
  { label: 'Wallet', key: null },
  { label: 'ETH', key: 'ethBalance' },
  { label: 'Win Rate 7Д', key: 'winRate' },
  { label: 'PNL 7Д %', key: 'realizedPnl' },
  { label: 'Прибыль 7Д $', key: 'realizedProfit' },
  { label: 'Buy 7Д', key: 'buyCount' },
  { label: 'Sell 7Д', key: 'sellCount' },
  { label: 'Токенов 7Д', key: 'tokenNum7d' },
  { label: 'P/L (этот токен)', key: 'thisTokenProfit' },
  { label: 'Найдено в N', key: 'foundInTokens' },
  { label: 'Метки', key: null },
  { label: 'Видел раньше', key: 'priorPassed' },
  { label: 'GMGN', key: null },
  { label: 'Действие', key: null }
];

function buildHeaderRow(table, onSort) {
  const tr = document.createElement('tr');
  tr.style.background = '#1a1a1a';
  COLUMNS.forEach((col) => {
    const th = document.createElement('th');
    th.textContent = col.label;
    th.style.cssText = 'border:1px solid #333; padding:8px; text-align:left; white-space:nowrap; color:#fff;' + (col.key ? ' cursor:pointer; user-select:none;' : '');
    if (col.key) {
      th.addEventListener('click', () => onSort(col.key));
      th.title = 'Нажми, чтобы отсортировать';
    }
    tr.appendChild(th);
  });
  table.appendChild(tr);
  return tr;
}

// ---------- плавающая панель с результатами (поверх интерфейса GMGN) ----------
function createPanel() {
  const overlay = document.createElement('div');
  overlay.id = 'rh-screener-panel';
  overlay.style.cssText = `
    position:fixed; top:56px; left:8px; right:8px; bottom:8px; z-index:999999;
    background:#0a0a0a; border:1px solid #333; border-radius:6px; overflow:auto;
    box-shadow:0 4px 24px rgba(0,0,0,0.6); font-family:sans-serif; font-size:13px;`;

  const header = document.createElement('div');
  header.style.cssText = 'position:sticky; top:0; background:#1a1a1a; color:#fff; padding:8px 12px; display:flex; justify-content:space-between; align-items:center; z-index:1;';
  header.innerHTML = `<b>Robinhood Chain Wallet Screener</b>`;
  const closeBtn = document.createElement('button');
  closeBtn.textContent = '✕ Закрыть';
  closeBtn.style.cssText = 'width:auto; padding:3px 10px;';
  closeBtn.addEventListener('click', () => overlay.remove());
  header.appendChild(closeBtn);
  overlay.appendChild(header);

  const body = document.createElement('div');
  body.style.padding = '8px 12px';
  overlay.appendChild(body);

  document.body.appendChild(overlay);
  return body;
}

async function init({
  wallets, extraTokens = [], minEthBalance = 0.05, minWinRate = 50, minRealizedPnl = 0,
  minTokenNum = 0, minTrades = 0, hideNoise = true, sheetsUrl = ''
}) {
  const primaryToken = getTokenAddressFromUrl();
  if (!primaryToken) {
    alert('Не нашёл адрес токена в ссылке. Открой страницу вида https://gmgn.ai/robinhood/token/0x...');
    return;
  }

  const uniqueTokens = [...new Set([primaryToken, ...extraTokens].map(t => (t || '').trim().toLowerCase()).filter(Boolean))];

  const existingPanel = document.getElementById('rh-screener-panel');
  if (existingPanel) existingPanel.remove();
  const body = createPanel();

  const table = document.createElement('table');
  table.style.cssText = 'width:100%; border-collapse: collapse; margin: 0; background: #0a0a0a; color:#ddd;';
  body.appendChild(table);

  const results = [];
  const sortState = { key: null, desc: true };

  function renderAll() {
    [...table.querySelectorAll('tr')].forEach(tr => {
      if (tr !== headerRow && tr !== statusRow) tr.remove();
    });
    for (const rowData of results) {
      table.insertBefore(renderRowElement(rowData, sheetsUrl), statusRow);
    }
  }

  function onSort(key) {
    if (sortState.key === key) sortState.desc = !sortState.desc;
    else { sortState.key = key; sortState.desc = true; }
    results.sort((a, b) => (sortState.desc ? b[key] - a[key] : a[key] - b[key]));
    renderAll();
  }

  const headerRow = buildHeaderRow(table, onSort);

  const statusRow = document.createElement('tr');
  statusRow.innerHTML = `<td style="border:1px solid #333; padding:8px; color:#ddd;" colspan="${COLUMNS.length}">Собираю холдеров/трейдеров с GMGN...</td>`;
  table.appendChild(statusRow);

  const manualWallets = (wallets || []).map(w => w.trim().toLowerCase()).filter(w => /^0x[a-fA-F0-9]{40}$/.test(w));

  // ---------- шаг 1: список кандидатов по всем указанным токенам (holders+traders) ----------
  // wallet -> { foundIn: Set(token), nativeBalance, tags: Set }
  const candidates = new Map();

  function record(tokenAddr, item) {
    const addr = (item.address || '').toLowerCase();
    if (!addr) return;
    if (!candidates.has(addr)) candidates.set(addr, { foundIn: new Set(), nativeBalance: '0', tags: new Set() });
    const entry = candidates.get(addr);
    entry.foundIn.add(tokenAddr);
    if (item.native_balance) entry.nativeBalance = item.native_balance;
    (item.tags || []).forEach(t => entry.tags.add(t));
    (item.maker_token_tags || []).forEach(t => entry.tags.add(t));
  }

  let tIdx = 0;
  for (const token of uniqueTokens) {
    tIdx++;
    statusRow.innerHTML = `<td style="border:1px solid #333; padding:8px; color:#ddd;" colspan="${COLUMNS.length}">Собираю холдеров/трейдеров по ${token} (несколько сортировок для максимального охвата)${uniqueTokens.length > 1 ? ` — токен ${tIdx}/${uniqueTokens.length}` : ''}...</td>`;
    const items = await fetchAllCandidates(token);
    for (const item of items) record(token, item);
  }
  for (const w of manualWallets) {
    if (!candidates.has(w)) candidates.set(w, { foundIn: new Set(), nativeBalance: '0', tags: new Set() });
  }

  const history = await loadHistory();
  const allWallets = [...candidates.keys()];

  // ---------- шаг 2: настоящий Win Rate/PNL (wallet_token_info) на каждого кандидата ----------
  let enriched = 0;
  await runWithConcurrency(allWallets, ENRICH_CONCURRENCY, async (wallet) => {
    enriched++;
    if (enriched % 5 === 0 || enriched === allWallets.length) {
      statusRow.innerHTML = `<td style="border:1px solid #333; padding:8px; color:#ddd;" colspan="${COLUMNS.length}">Запрашиваю реальный Win Rate/PNL: ${enriched}/${allWallets.length}...</td>`;
    }
    const entry = candidates.get(wallet);
    const info = await fetchWalletTokenInfo(wallet, primaryToken);
    const ethBalance = weiToEth(entry.nativeBalance);
    const tags = [...new Set([...entry.tags, ...(info?.tags || [])])];
    const isNoise = hideNoise && tags.some(t => NOISE_TAGS.includes(t));
    let passed = false;

    if (info && !isNoise) {
      const winRate = info.winRate7d;
      const realizedPnl = info.realizedPnl7d;
      const totalTrades = info.buy7d + info.sell7d;
      const passesFilters =
        (isNaN(ethBalance) || ethBalance >= minEthBalance) &&
        winRate >= minWinRate &&
        realizedPnl >= minRealizedPnl &&
        info.tokenNum7d >= minTokenNum &&
        totalTrades >= minTrades;

      if (passesFilters) {
        passed = true;
        const foundInTokens = entry.foundIn.size || 1;
        const priorPassed = bumpHistory(history, wallet, true);
        const rowData = {
          wallet, ethBalance, winRate, realizedPnl,
          realizedProfit: info.realizedProfit7d, buyCount: info.buy7d, sellCount: info.sell7d,
          tokenNum7d: info.tokenNum7d, thisTokenProfit: info.thisTokenProfit,
          foundInTokens, tokens: entry.foundIn.size ? [...entry.foundIn] : [primaryToken],
          tags, priorPassed
        };
        results.push(rowData);
        table.insertBefore(renderRowElement(rowData, sheetsUrl), statusRow);
      }
    }
    if (!passed) bumpHistory(history, wallet, false);
  });

  await saveHistory(history);
  statusRow.innerHTML = `<td style="border:1px solid #333; padding:8px; color:#ddd;" colspan="${COLUMNS.length}">Закончил (проверено ${allWallets.length} кошельков, найдено ${results.length})</td>`;
}
